#include <httpserver.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
typedef struct def{
	char ip[128];
	int count = 0;
	int flag = 0;
};

int denyList;
static def list[1024];
def* is_available(char *address) {
	for(int i = 0; i < 1024; i++) {
		if(strcmp(list[i].ip, address) == 0)
			return &list[i];
	}
	return NULL;
}
void defense(struct evhttp_connection* connp) {
  assert(connp);
  denyList = open("./denyList.txt", O_RDWR);
  struct sockaddr *address;
  address = evhttp_connection_get_addr(connp);
  struct def name;

  if ((name = is_available(address))) {
    if(name.count <= 50) {
      name.count++;
    } else {
		evhttp_connection_free(connp);
		write(denyList, address, strlen(address));
    }
  } else {
    for(int i = 0; i < 1024; i++) {
		if (list[i].count == 0)
			list[i].flag = 0;
		if (list[i].flag == 0){
			strcpy(list[i].ip, address);
			list[i].count++;
			list[i].flag = 1;
		}
	}
}
}

