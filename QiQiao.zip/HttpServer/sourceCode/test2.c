#include <stdio.h>
#include <time.h>
#include <sys/stat.h>

char *get_last_modified(char *file) {
    struct tm *clock;
    struct stat attr;

    stat(file, &attr);
    clock = gmtime(&(attr.st_mtime));

    return asctime(clock);
}

int main() {
	printf("%s\n", get_last_modified("./test2.c"));
}
