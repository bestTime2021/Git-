#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>

#define LEN 128
char buf[LEN];

int main() {
	pid_t pid;
	if ((pid = fork()) > 0)	//脱离终端控制
		exit(0);
	setsid();				//child1成为新的会话头，无终端会话头会被终端控制，
	signal(SIGHUP, SIG_IGN);//忽略会话头的挂起
	if ((pid = fork()) > 0) //放弃child1，使用不是会话头的child2
		exit(0);

	getcwd(buf, LEN);
	printf("%s\n", buf);

	chdir("/");

	getcwd(buf, LEN);
	printf("%s\n", buf);
}
