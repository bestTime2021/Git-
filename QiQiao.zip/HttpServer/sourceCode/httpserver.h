#include <stdio.h>
#include <unistd.h> //getopt()
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>
#include <time.h>
#include <wait.h>
#include <dirent.h>
#include <signal.h>

#include <errno.h>
#include <assert.h>
#include <string.h>
/*libevent*/
#include <event2/event.h>
#include <event2/http.h>
#include <event2/listener.h>
#include <event2/buffer.h>
#include <event2/util.h>
#include <event2/keyvalq_struct.h>
#include "Log/log.c"
#include "config.h"
#include "mimetype.h"
#include "Auth/base64.c"

#define HTTP_FORBIDDEN 403
#define NO_EXTENSION NULL

/* default setting */
void http_setting(struct evhttp* http_server);

/* resource reslove */
char* get_file_extension(const char* file_path); 
char* get_mime_type(const char* file_path);
char* get_request_method(struct evhttp_request *req, char *cmdtype); 
char* get_whole_path(struct evhttp_request *req, char *docroot); 

/* resource select */
void forward_req_cb(struct evhttp_request *req, void *arg);
void private_req_cb(struct evhttp_request *req, void *whole_path);
void static_handle(struct evhttp_request *req, char *whole_path);
void dynamic_handle(struct evhttp_request *req, char *whole_path);

/* send response */
void ctor_response_header(struct evhttp_request *req, char *whole_path);
void send_server_info(struct evhttp_request *req);
void send_header(struct evhttp_request *req, char *whole_path);
void send_document(struct evhttp_request *req, char *whole_path);
void send_directory(struct evhttp_request *req, char *whole_path);

/* Connection */
int is_connection_keepalive(struct evkeyvalq* headers);
void* connection_close_cb(struct evhttp_connection *evconn, void *msg);

