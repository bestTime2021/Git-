#include <inttypes.h>

char* get_etag(char *whole_path);
char* get_last_modified(char *file);
int is_cacheable(struct evhttp_request *req, char *whole_path) ;

char* get_last_modified(char *file) {
    struct tm *clock;
    struct stat attr;
	char *timeline = NULL;
	
	timeline = malloc(32);

    stat(file, &attr);
    clock = gmtime(&(attr.st_mtime));
    strftime(timeline,sizeof(timeLine),"%a, %d %b %Y %H:%M:%S GMT",clock);

	return timeline;
}


char* get_etag(char *whole_path) {
	struct stat file_stat;
	char *etag = NULL;

	etag = malloc(32);
	stat(whole_path, &file_stat);

    sprintf(etag, "\"%" PRIx64 "-%" PRIx64 "\"", file_stat.st_mtime, file_stat.st_size);
    return etag;
}


int is_cacheable(struct evhttp_request *req, char *whole_path) {
	int					ret = -1;
	char				*etag = NULL;
	char				*last_m = NULL;
	struct evkeyvalq	*inheaders = evhttp_request_get_input_headers(req);
	const char			*ims = evhttp_find_header(inheaders, "If-Modified-Since");
	const char			*inm = evhttp_find_header(inheaders, "If-None-Match");

	etag	= get_etag( whole_path);
	last_m	= get_last_modified(whole_path);
	if (ims != NULL)
		ret = strncmp(ims, last_m, strlen(last_m));
	if (inm != NULL)
		ret |= strncmp(inm, etag, strlen(etag)); //FIXME error when(etag: abc-a inm: abc-ad)

	if (etag)
		free(etag);
	if (last_m)
		free(last_m);
	return !(ret);
}

