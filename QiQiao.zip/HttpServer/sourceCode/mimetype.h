/*QiQiao allows these types*/

#include <stdio.h>
static const char* static_types[][2] = {
    { "html", "text/html" },
    { "htm", "text/html" },
    { "txt", "text/plain" },
    { "css", "text/css" },
		{ "c", "text/plain" },
		{ "h", "text/plain" },
		{ "css", "text/css" },
		{ "gif", "image/gif" },
		{ "png", "image/png" },
		{ "gif", "image/gif" },
    { "jpeg", "image/jpeg" },
    { "jpg", "image/jpeg" },
    { "png", "image/png" },
    { "ico", "image/avif" },
    { "pdf", "application/pdf" },
    { "zip", "application/zip" },
    { "gz", "application/gzip" },
    { "tar", "application/x-tar" },
		{ "ps", "application/postscript" },
    { "js", "application/javascript" },
    { "json", "application/json" },
    { "xml", "application/xml" },
    { "mp3", "audio/mpeg" },
    { "mp4", "audio/mpeg" },
    { "wav", "audio/wav" },
    { NULL, NULL }
};


