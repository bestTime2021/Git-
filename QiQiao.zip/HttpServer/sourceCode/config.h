#define MAX_WORKERS 1
#define MAX_HEADER_SIZE 4 * 1024
#define MAX_BODY_SIZE 10 * 1024 * 1024
#define DOCROOT "/root/HttpServer/www" 

#define DIR_ACCESSABLE 1


