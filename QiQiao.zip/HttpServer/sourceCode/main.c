#include "httpserver.c"
#include <sys/prctl.h>

#define MAXFD 64

void deamon(char *pname) {
	pid_t pid;
	if ((pid = fork()) > 0)	//脱离终端控制
		exit(0);
	setsid();				//child1成为新的会话头，无终端会话头会被终端控制，
	signal(SIGHUP, SIG_IGN);//忽略会话头的挂起
	if ((pid = fork()) > 0) //放弃child1，使用不是会话头的child2
		exit(0);

	chdir("/");

	for (int i = 0; i < MAXFD; i++)
        close(i);
 
    /* redirect stdin, stdout, and stderr to /dev/null */
    open("/dev/null", O_RDONLY);
    open("/dev/null", O_RDWR);
    open("/dev/null", O_RDWR);
 
}
int main(int argc, char **argv) {
	signal(SIGPIPE, SIG_IGN);
	struct event_base *base;
	struct evhttp *http_server;
	struct evhttp_bound_socket *handle;

	base = event_base_new();
	http_server = evhttp_new(base);

	evhttp_set_gencb(http_server, forward_req_cb, DOCROOT);
	handle = evhttp_bind_socket_with_handle(http_server, "0.0.0.0", 8888);
	assert(handle);
	
	http_setting(http_server);
	printf("Hello QiQiao\n");
	
	for (int i = 0; i < MAX_WORKERS; ++i) {
		pid_t pid = fork();
		if (pid == 0) {
			prctl(PR_SET_NAME, "worker", NULL, NULL, NULL);
			Log_Init();
			event_base_dispatch(base);
			exit(1);
		}
	}
	Log_Init();
	while(1) {
		sleep(10);
		Log_Write();
		fflush(logfile);
		sleep(20);
	}


	waitpid(-1, NULL, 0);
	return 0;
}

