#include <unistd.h> //fork(), execve(), pause()
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>
#include <stdarg.h>

#define TIMELEN 64
void Log_Time(char *time_string);

void Log_Time(char *time_string) {
	struct tm* ptm;
	struct timeval tv;
  
  gettimeofday (&tv, NULL);
  ptm = localtime (&tv.tv_sec);
  strftime (time_string,  TIMELEN, "%Y-%m-%d %H:%M:%S", ptm);
}

#include <string.h>
#include <event2/buffer.h>

int main(int argc, char **argv){
	struct evbuffer* buf = evbuffer_new();
	char ts[TIMELEN];
	Log_Time(ts);
	int len = strlen(argv[2]);
	int len2;
	char *pos = strchr(argv[2], '=');
	len2 = pos - argv[2];
	evbuffer_add(buf, pos + 1, len - len2);
	evbuffer_add_printf(buf, "\n%s", ts);
	evbuffer_write(buf, STDOUT_FILENO);
  return 0;
}
