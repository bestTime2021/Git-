#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>

#include <event2/buffer.h>

int main() {
	int fd = open("/home/laidong/HttpServer/www/static/test.jpg", O_RDONLY);
	if (fd < 0)
		printf("open failed\n");
	struct evbuffer *buf = evbuffer_new();
	//1 evbuffer_read(buf, fd, 4097); 
	evbuffer_add_file(buf, fd, 0, -1);
	printf("len = %d\n", (int)evbuffer_get_length(buf));
}
