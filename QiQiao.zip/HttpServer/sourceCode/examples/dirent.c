#include <sys/stat.h>
#include <dirent.h>

void handle_request( void *arg) {
    const char *docroot = "/var/www"; // replace with your web server's document root
    DIR *dir = opendir(path);
    if (!dir) {
        evhttp_send_error(req, HTTP_INTERNAL, "Internal server error");
        return;
    }
    struct dirent *entry;
    while ((entry = readdir(dir))) {
       evbuffer_add_printf(buf, "<li><a href=\"%s/%s\">%s</a></li>", uri, entry->d_name, entry->d_name);
    }
    evbuffer_add_printf(buf, "</ul></body></html>");
    evhttp_add_header(evhttp_request_get_output_headers(req), "Content-Type", "text/html");
		closedir(dir);
}

int main() {
}
