#include <event2/buffer.h>
#include <stdio.h>

int main() {
    // 创建两个evbuffer对象
    struct evbuffer *buf1 = evbuffer_new();
    struct evbuffer *buf2 = evbuffer_new();

    // 向buf1中添加数据
    evbuffer_add_printf(buf1, "Hello, World!");

    // 将buf1的内容复制到buf2
    evbuffer_add_buffer_reference(buf2, buf1);

    // 在控制台打印buf2中的内容
    size_t len = evbuffer_get_length(buf2);
    unsigned char *data = evbuffer_pullup(buf1, len);
    unsigned char *data2 = evbuffer_pullup(buf2, len);
    printf("%.*s, %s\n", (int)len, data, data2);

    // 释放evbuffer对象
    evbuffer_free(buf1);
    evbuffer_free(buf2);

    return 0;
}
