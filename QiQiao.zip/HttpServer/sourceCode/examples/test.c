#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>
#include <stdarg.h>
#include <string.h>

#define TIMELEN 64
#define PATHLEN 64
#define DOCROOT "/var/log/QiQiao/"

struct Log {
	int logfile;
	char logtime[TIMELEN];
	char logpath[PATHLEN];
};
int logfile;

enum LOGLEVEL {
	INFO = 0,
	DEBUG = 1,
	WARNING = 2,
	ERR = 3,
	ALERT = 4
}; 
const static char LogLevelText[5][10]={"INFO","DEBUG","WARN","ERROR", "ALERT"}; 

enum LOGTYPE {
	PROGRAM = 0,
	SERVER = 1
};
const static char LogTypeText[2][10] = {"PROGRAM", "SERVER"};

void get_date(char *date) {
	struct timeval tv;
	struct tm *tm;
	gettimeofday(&tv, NULL);
  tm = localtime (&tv.tv_sec);
  strftime (date,  TIMELEN, "%Y%m%d", tm);
}
void get_path(char *path, char *docroot) {
	char date[TIMELEN];
	get_date(date);
	sprintf(path, "%sqiqiao-%s.log", docroot, date);	
}
void Log_Init() {
	char path[PATHLEN];
	get_path(path, DOCROOT);
	logfile = open(path, O_CREAT | O_WRONLY | O_APPEND, 0666);
}

void Log_Print(char *format, va_list args);
void Log_Time(char *time_string);

/*[Level] time msg func*/
void Log_Write(int levelno, int typeno, char *format, ...) {
	va_list args;
	char time_string[TIMELEN];

	va_start(args, format);
	dprintf(logfile, "[%s] ", LogLevelText[levelno]);
	Log_Time(time_string);
	dprintf(logfile, "%s ", time_string);
	Log_Print(format, args);
	dprintf(logfile, " (%s) %s()\n", LogTypeText[typeno], __func__);
	va_end(args);
}

int main() {
	Log_Init();
	Log_Write(DEBUG, SERVER, "Not found %d %s %d %d", getpid(), "request-line", 404, 1024);
}




void Log_Print(char *format, va_list args) {
	int d;
	char c, *s;
	int has_percent = 0;
	
	while(*format)
	{
		switch(*format){
			case '%' :
				has_percent = 1;
				break;
			case's':{
				if (has_percent) {
					s =va_arg(args,char*);
					dprintf(logfile,"%s",s);
					has_percent = 0;
				} else {
					dprintf(logfile, "s");
				}
				break;
			}
			case'd':{
				if (has_percent) {
					d =va_arg(args,int);
					dprintf(logfile,"%d",d);
					has_percent = 0;
				} else {
					dprintf(logfile, "d");
				}
				break;
			}
			case'c':{
				if (has_percent) {
					c =(char)va_arg(args,int);
					dprintf(logfile,"%c",c);
					has_percent = 0;
				} else {
					dprintf(logfile, "c");
				}
				break;
			}
			default:{
				if(*format!='%')
					dprintf(logfile,"%c",*format);
				break;
			}
		}
	format++;
	}
}
void Log_Time(char *time_string) {
	struct tm* ptm;
	struct timeval tv;
	if (gettimeofday(&tv, NULL) == -1) {
		dprintf(logfile, "%s:gettimeofday() error\n", __func__);
	}
  
  //gettimeofday (&tv, NULL);
  ptm = localtime (&tv.tv_sec);
  strftime (time_string,  TIMELEN, "%Y-%m-%d %H:%M:%S", ptm);
}

