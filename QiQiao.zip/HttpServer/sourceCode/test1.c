#include<stdio.h>
#include"string.h"
void main()
{
int n;
n=strcmp("2010-05-02:12","2010-05-02:11");//再根据n进行判断
printf("%d\n",n);
}
