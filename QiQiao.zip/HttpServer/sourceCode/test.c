#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>

int main() {
struct tm* ptm;
  char time_string[40];
  long milliseconds;
	struct timeval tv;
	if (gettimeofday(&tv, NULL) == -1) {
		printf("error\n");
		return 0;
	}
  
  gettimeofday (&tv, NULL);
  ptm = localtime (&tv.tv_sec);
  strftime (time_string, sizeof (time_string), "%Y-%m-%d %H:%M:%S", ptm);
  milliseconds = tv.tv_usec / 1000;
  printf ("%s.%03ld\n", time_string, milliseconds);
}
