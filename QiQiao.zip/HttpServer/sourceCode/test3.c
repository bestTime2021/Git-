#include <time.h>
#include <stdio.h>

int main() {
	time_t seconds;
	struct tm *tmp, *tmp2;
	char timeLine[64];
	
	/* create */
	seconds = time(NULL);	//time_t time(time_t *timer);

	/* convert */
	tmp = gmtime(&seconds);
	tmp2 = localtime(&seconds);

	/* format */
    strftime(timeLine,sizeof(timeLine),"%a, %d %b %Y %H:%M:%S GMT",tmp);

	/* printf */
	printf("ctime(seconds): %s\n", ctime(&seconds));
	printf("asctime(tmp):   %s\n", asctime(tmp));
	printf("asctime(tmp2):  %s\n", asctime(tmp));
	printf("strftime(...):  %s\n", timeLine);
}
