#include <sys/stat.h>
#include <stdio.h>
#include <time.h>
#include <inttypes.h>

char *mketag(char *s, struct stat *sb)
{
    sprintf(s, "\"%" PRIx64 "-%" PRIx64 "\"", sb->st_mtime, sb->st_size);
    return s;
}

int main() {
	struct stat file_stat;
	char *abs_path = "./httpserver.c";
	struct tm *tmp;

	char etag[32];

	stat(abs_path, &file_stat);
	tmp = gmtime(&(file_stat.st_mtime));
	mketag(etag, &file_stat);

	printf("%s's inode is %u\n", abs_path, file_stat.st_ino);
	printf("%s's size is %ld\n", abs_path, file_stat.st_size);
	printf("%s's mtime is %s", abs_path, asctime(tmp));
	printf("The etag is %s\n", etag);
}
