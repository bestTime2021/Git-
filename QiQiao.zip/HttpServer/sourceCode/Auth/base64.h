#ifndef __BASE64_H__
#define __BASE64_H__

#include <stdlib.h>  
#include <string.h>  
#include <stdint.h>
  
char *base64_encode(char *str);  
char *base64_decode(char *code);
  
#endif
