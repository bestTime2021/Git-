#!/bin/sh
set -x

# __LOG__
mkdir -p /var/log/QiQiao
cp -u Log/logconfig /etc/logrotate.d/QiQiao
sysctl -w fs.mqueue.queues_max=256
sysctl -w fs.mqueue.msg_max=1024
sysctl -w fs.mqueue.msg_default=128
sysctl -w fs.mqueue.msgsize_max=4096
# end __LOG__

gcc main.c -levent -lrt -o qiqiao \
&& echo "\nYou have successfully compile."
