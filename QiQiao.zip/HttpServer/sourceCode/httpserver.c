char timeLine[64];

#include "httpserver.h"
#include <inttypes.h>
#include "cache.c"

/* default setting */
void http_setting(struct evhttp* http_server);

/* resource mapping */
char* get_file_extension(const char* file_path); 
char* get_mime_type(const char* file_path);
char* get_request_method(struct evhttp_request *req, char *cmdtype); 
char* get_whole_path(struct evhttp_request *req, char *docroot); 

/* resource select */
void forward_req_cb(struct evhttp_request *req, void *docroot);
void private_req_cb(struct evhttp_request *req, void *whole_path);
void static_handle(struct evhttp_request *req, char *whole_path);
void dynamic_handle(struct evhttp_request *req, char *whole_path);

/* send response */
void ctor_response_header(struct evhttp_request *req, char *whole_path);
void send_server_info(struct evhttp_request *req);
void send_header(struct evhttp_request *req, char *whole_path);
void send_document(struct evhttp_request *req, char *whole_path);
void send_directory(struct evhttp_request *req, char *whole_path);

/* Connection */
int is_connection_keepalive(struct evkeyvalq* headers);
void* connection_close_cb(struct evhttp_connection *evconn, void *msg);

void forward_req_cb(struct evhttp_request *req, void *docroot) {
	char *whole_path;
	whole_path = get_whole_path(req, (char*)docroot);
	if(is_cacheable(req, whole_path)) {
		ctor_response_header(req, whole_path);
		evhttp_send_reply(req, 304, "Not Modified", NULL);
		free(whole_path);
		return;
	}
	if (strstr(whole_path, "static") != NULL) {
		//Log_Send(INFO, SERVER, "%s:%s %s", evhttp_request_get_host(req), evhttp_request_get_uri(req), __func__);
		static_handle(req, whole_path);
	}	else if (strstr(whole_path, "app") != NULL) {
		//Log_Send(INFO, SERVER, "%s:%s %s", evhttp_request_get_host(req), evhttp_request_get_uri(req), __func__);
		dynamic_handle(req, whole_path);
	} else if (strstr(whole_path, "private")) {
		private_req_cb(req, whole_path);
	}else{
		evhttp_send_error(req, 404, "To be sure your file in /static or /app");
	}

	if (whole_path)
		free(whole_path);
}

/*   static_handle
 * 1.get the method
 *			if allow method
 *					GET/POST:		send_document
 *					HEAD:				send_head
 *					OPTIONS:		send_server_info
 *			esif no allow
 *					405 no support.
 */
void static_handle(struct evhttp_request *req, char *whole_path){
	enum evhttp_cmd_type		method;

	method = evhttp_request_get_command(req);
	switch(method) {
		case EVHTTP_REQ_GET: 
		case EVHTTP_REQ_POST:		send_document(req, whole_path); break;
		case EVHTTP_REQ_HEAD:		send_header(req, whole_path); break;
		case EVHTTP_REQ_OPTIONS:	send_server_info(req); break; 
		default :
		{
			Log_Send(INFO, SERVER, "No Support this Method method:url:%s  resp_code:"
			,evhttp_request_get_uri(req));
			evhttp_send_error(req, HTTP_BADMETHOD, "No Support this Method\n");
			break;
		}
	}

	return;
}

/*    dynamic handle
 * 1. getting req method
 *		if GET,			getdata from header
 *		esif POST,	getdata from body
 *		else				500 no allow
 * 2. pipe() for msg transfer between father and cgichild
 *		fork()
 *		dup2(), execve() in child.
 */
void dynamic_handle(struct evhttp_request *req, char *whole_path) {
	int							fds[2];
	enum evhttp_cmd_type		method;
	struct evkeyvalq			*inheader, *outheader;
	struct evbuffer				*inbuf, *outbuf, *buf;
	char						*post_type = NULL;
	char						*post_data = NULL;
	size_t						inbuf_len = -1;
	pid_t						pid;

	buf				= evbuffer_new();
	method		= evhttp_request_get_command(req);
	inheader	= evhttp_request_get_input_headers(req);
	outheader = evhttp_request_get_output_headers(req);
	inbuf			= evhttp_request_get_input_buffer(req);
	outbuf		= evhttp_request_get_output_buffer(req);
	inbuf_len = evbuffer_get_length(inbuf);
	post_type =(char *) evhttp_find_header(inheader, "Content-Type");
	post_data = NULL;
	if (post_type != NULL || method == EVHTTP_REQ_POST) {
		post_data = (char*)malloc(inbuf_len + 1);
		memcpy(post_data, evbuffer_pullup(inbuf, -1), inbuf_len);
		post_data[inbuf_len] = '\0';
	} else {
		post_data = (char*)evhttp_uri_get_query(evhttp_request_get_evhttp_uri(req));
	}

	if (method == EVHTTP_REQ_GET ||
		method == EVHTTP_REQ_POST) {
		if(pipe(fds) == -1) {
			evhttp_send_error(req, 502, "Internal Error\n");
			Log_Send(DEBUG, PROGRAM, "pipe: %s %s", strerror(errno), __func__);
		}
		if ( (pid = fork()) < 0) {
			evhttp_send_error(req, 502, "Internal Error\n");
			Log_Send(DEBUG, PROGRAM, "fork: %s %s", strerror(errno), __func__);
		} else if ( pid == 0) {
			close(fds[0]);
			int writefd = fds[1];
			char *args[] = {whole_path, post_type, post_data, NULL};
			dup2(writefd, STDOUT_FILENO);//dup old to new
			execv(whole_path, args);
		} else {
		/*		receive data from child.
		 * 1. read return_content_type
		 * 2. read return_content_data
		 * 3. construt the dynamic_reponse_header, and dynamic_response
		 * 4. send back to user agent.
		 */
			close(fds[1]);
			int n;
			int readfd = fds[0];
			while ((n = evbuffer_read(buf, readfd, 1024)) > 0) {
				evbuffer_add_buffer(outbuf, buf);
			}
				
			int status;
			waitpid(-1, &status,0); 
			evhttp_add_header(outheader, "Content-Type", "text/html");
			evhttp_send_reply(req, 200, "OK", NULL);
		}
	} else {
			evhttp_send_error(req, 500, "Not allow the method for dynamic resource");
	}
}
 /*
	*		 private_req_cb
	* 1. if no Authorization header
	*				response 401
	*
	* 2. if Authorization
	*				verify?
	*				if success,	static_handle()
	*				if failed,	return 401
  */

void private_req_cb(struct evhttp_request *req, void *arg) {
	struct evkeyvalq		*inheader, *outheader;
	char					*auth_header;
	char					*decoded;
	char					*username = NULL;
	char					*password = NULL;
	char					*whole_path = (char *) arg;

	inheader		= evhttp_request_get_input_headers(req);
	outheader		= evhttp_request_get_output_headers(req);
	if ( (auth_header = (char*) evhttp_find_header(inheader, "Authorization")) == NULL) {
		evhttp_add_header(evhttp_request_get_output_headers(req), "WWW-Authenticate", "Basic reaml=QiQiao");
		evhttp_send_reply(req, 401, "No Authorization", NULL);
	} else {
		decoded = base64_decode(auth_header+6);
		//printf("entire:%s\n", decoded);
		Log_Send(INFO, SERVER, "auth: %s, %s:%s %s",decoded, evhttp_request_get_host(req), evhttp_request_get_uri(req), __func__);
		char *pos = strchr((char*)decoded, ':');
		password = pos + 1;
		*pos = '\0';
		username = (char*)decoded;
		//printf("un:%s\n", username);
		//printf("ps:%s\n", password);
		for (int i = 0; i < 2; ++i) {
			if (strcmp(username, users[i].username) == 0
			&& strcmp(password, users[i].password) == 0
								) {
				static_handle(req, whole_path);
				if (decoded)
					free(decoded);
				return;
			}
		}
	evhttp_add_header(outheader, "WWW-Authenticate", "Basic");
	evhttp_send_reply(req, 401, "No Authorization", NULL);
			
	}
}

void send_header(struct evhttp_request *req, char *whole_path) {
		ctor_response_header(req, whole_path);
		evhttp_send_reply(req, 200, "OK", NULL);
}

/*send_document
 * 1.open whole_path
 * 2.check the path is DIR or not
 *		if DIR, check the "config.h" for DIR_ACCESSABLE
 *			if accessable,	send the dir.
 *			esif not,				send 403 diraccess denied.	
 * 3.set EVBUFFER_FLAG_DRAINS_TO_FD for sendfile function maybe.
 */
void send_document(struct evhttp_request *req, char *whole_path) {
    int							fd;
	struct stat					st;
	struct evbuffer*			evb; 
	assert(whole_path);
	
	fd		= open(whole_path, O_RDONLY);
	evb		= evbuffer_new();
	evbuffer_set_flags(evb, EVBUFFER_FLAG_DRAINS_TO_FD);
	if(fd == -1) {
		evhttp_send_error(req, HTTP_BADREQUEST, "Cannot find the file");
		Log_Send(INFO, SERVER, "%s:%s %s", evhttp_request_get_host(req), evhttp_request_get_uri(req), __func__);
		return;
	}

	if (stat(whole_path, &st) < 0) {
		Log_Send(DEBUG, PROGRAM, "can not get the file state %s", __func__);
		evhttp_send_error(req, HTTP_INTERNAL, "Internal error");
		close(fd);
		return;
    }
    if (S_ISDIR(st.st_mode)) { 
		if (DIR_ACCESSABLE == 0) {
			Log_Send(DEBUG, PROGRAM, "Cannot access the DIR: %s %s %s", 
					whole_path, strerror(errno),  __func__);
			evhttp_send_error(req, HTTP_FORBIDDEN, "DIR Access denied");
			return;
		} else {
			send_directory(req, whole_path);
	}
}	
		
    /*construst response*/
    //FIXME
	ctor_response_header(req, whole_path);
    evbuffer_add_file(evb, fd, 0, -1);
    evhttp_send_reply(req, HTTP_OK, "OK", evb);
	if (evb) {
		evbuffer_free(evb);
    }
}

void send_directory(struct evhttp_request *req, char *whole_path){
	struct evbuffer			*evb;
    DIR						*dir;
    struct dirent			*entry; 

	evb		= evbuffer_new(); 
	dir		= opendir(whole_path);
    if (!dir) {
		fprintf(stderr, "opendir error %s\n", __func__);
        evhttp_send_error(req, HTTP_INTERNAL, "Internal server error");
        return;
    }

	evbuffer_add_printf(evb, "<html><head><title>Directory listing for %s</title></head><body><h1>Directory listing for %s</h1><ul>", whole_path, whole_path);
    while ((entry = readdir(dir))) {
       evbuffer_add_printf(evb, "<li><a href=\"%s/%s\">%s</a></li>", evhttp_request_get_uri(req), entry->d_name, entry->d_name);
    }
    evbuffer_add_printf(evb, "</ul></body></html>");
	ctor_response_header(req, whole_path);
	evhttp_send_reply(req, HTTP_OK, "OK", evb);
//	printf("%s\n", whole_path);	
	closedir(dir);
    if (evb) {
        evbuffer_free(evb);
    }

}

void send_server_info(struct evhttp_request *req) {
	evhttp_add_header(evhttp_request_get_output_headers(req), "Access-Control-Allow-Origin", "*");
	evhttp_add_header(evhttp_request_get_output_headers(req), "Access-Control-Allow-Methods", "GET, POST, OPTIONS");
	evhttp_add_header(evhttp_request_get_output_headers(req), "Access-Control-Allow-Headers", "Authorization, Content-Type");
	evhttp_send_reply(req, 204, "", NULL);
}

char* get_file_extension(const char* file_path) {
    char* dot = strrchr(file_path, '.');

	if (!dot || dot == file_path) {
       return NO_EXTENSION;
    }
    return dot + 1;
}

char* get_mime_type(const char* file_path) {
	const char* extension = get_file_extension(file_path);
	if (extension == NULL)
  	    return "text/html";
	for (int i = 0; static_types[i][0]; ++i) {
	    if (strcmp(extension, static_types[i][0]) == 0) {
			return (char*)static_types[i][1];
		}
  	}
	return "text/html";
}


/* get_whole_path()
 * malloc a $whole_path as absolut path.
 *
 * Return: NULL: not a good URL.
 *         char: value of abs path.
 *
 * [uri] -> [decode] -> [path] -> [decoded_path] -> [whole_path]
 *
 * Tips: Remeber to free the malloc.
 */
char* get_whole_path(struct evhttp_request *req, char *docroot) {
    char*				whole_path = NULL;
    struct evhttp_uri*	decoded = NULL;
    const char*			uri = evhttp_request_get_uri(req);
    char*				path;
    char*				decoded_path;
    size_t				path_len = 0;

    decoded = evhttp_uri_parse(uri);
    if (!decoded) {
		printf("It's not a good URI. Sending BADREQUEST\n");
		evhttp_send_error(req, HTTP_BADREQUEST, 0);
		return NULL;
    } else if (strcmp((path = (char*)evhttp_uri_get_path(decoded)), "/") == 0) {
		decoded_path = "/static/index.html";
    } else {
		decoded_path = evhttp_uridecode(path, 0, NULL);
    }

    /*get the whole uri*/
    path_len	= strlen(decoded_path) + strlen(docroot) + 2;
    whole_path	= malloc(path_len);
    snprintf(whole_path, path_len, "%s%s", docroot, decoded_path);
    if (decoded)
		evhttp_uri_free(decoded);
		
    return whole_path;
}

int is_connection_keepalive(struct evkeyvalq* headers)
{
    const char *connection = evhttp_find_header(headers, "Connection");
	  return (connection != NULL
       && evutil_ascii_strncasecmp(connection, "keep-alive", 10) == 0);
}	

void ctor_response_header(struct evhttp_request *req, char *whole_path) {
	assert(whole_path);
	const char					*type;
	struct evhttp_connection	*evconn = evhttp_request_get_connection(req);
	char						*etag = get_etag(whole_path);
	char						*timeline = get_last_modified(whole_path);

	type = get_mime_type(whole_path);
    /*construst response*/

    evhttp_add_header(evhttp_request_get_output_headers(req), "Last-Modified", timeline);
    evhttp_add_header(evhttp_request_get_output_headers(req), "ETag", etag);
    evhttp_add_header(evhttp_request_get_output_headers(req), "Content-Type", type);
    if (is_connection_keepalive(evhttp_request_get_input_headers(req))) {
        evhttp_add_header(evhttp_request_get_output_headers(req), "Connection", "keep-alive");
		evhttp_add_header(evhttp_request_get_output_headers(req), "Keep-Alive", "timeout=60");
		evhttp_connection_set_timeout(evconn, 60);
    } else {
		evhttp_add_header(evhttp_request_get_output_headers(req), "Connection", "close");
		struct evhttp_connection *evconn = evhttp_request_get_connection(req);
		evhttp_connection_free_on_completion(evconn);
	}
	
    const char *cacheable = evhttp_find_header(evhttp_request_get_input_headers(req), "Cache-Control");
	//if (strcmp(cacheable, "max-age=0"))
	//	evhttp_add_header(evhttp_request_get_output_headers(req), "Cache-Control", "max-age=0");
	//else
	evhttp_add_header(evhttp_request_get_output_headers(req), "Cache-Control", "max-age=60");
    evhttp_add_header(evhttp_request_get_output_headers(req), "Server", "QiQiao/1.1");
    evhttp_add_header(evhttp_request_get_output_headers(req), "X-Ua-Compatible", "IE=Edge,chrome=1");
    //printf("handle %d requests\n", deal_with_num++);
	if (etag) 
		free(etag);
}

void* connection_close_cb(struct evhttp_connection *evconn, void *arg) {
	struct evhttp_request *req = (struct evhttp_request*)arg;	
	evhttp_send_error(req, 407, "Timeout");
	return NULL;
}

void http_setting(struct evhttp* http_server) {
	evhttp_set_allowed_methods(http_server, EVHTTP_REQ_OPTIONS |
											EVHTTP_REQ_HEAD |
											EVHTTP_REQ_GET |
											EVHTTP_REQ_POST |
											EVHTTP_REQ_PUT |
											EVHTTP_REQ_DELETE);

	evhttp_set_max_headers_size(http_server, MAX_HEADER_SIZE);
	evhttp_set_max_body_size(http_server, MAX_BODY_SIZE);
}
