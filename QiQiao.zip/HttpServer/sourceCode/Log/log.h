#ifndef __LOG_H__
#define __LOG_H__
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>
#include <stdarg.h>
#include <string.h>

#include <mqueue.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>


#define TIMELEN 64
#define PATHLEN 64
#define LOGROOT "/var/log/QiQiao/"
#define MQD_NAME "/mqd"
#define MQ_MSGSIZE 8192

enum LOGLEVEL {
	INFO = 0,
	DEBUG = 1,
	WARNING = 2,
	ERR = 3,
	ALERT = 4
}; 

enum LOGTYPE {
	PROGRAM = 0,
	SERVER = 1
};

void Log_Init();
void Log_Send(int levelno, int typeno, char *format, ...);
void Log_Write();
#endif/* __LOG_H__ */
