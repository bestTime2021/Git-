#include "log.h"

static char LogLine[MQ_MSGSIZE];
FILE *logfile;
mqd_t mqd;
const static char LogLevelText[5][10]={"INFO","DEBUG","WARN","ERROR", "ALERT"}; 
const static char LogTypeText[2][10] = {"PROGRAM", "SERVER"};

void Log_Init();

void Log_Send(int levelno, int typeno, char *format, ...);
void Log_Write();

void Log_Fill_LogLine(int levelno, int typeno, char *format, va_list args);
void Log_Print(char *format, va_list args);
void Log_Time(char *time_string);

void get_date(char *date);
void get_path(char *path, char *docroot);

/* Impletation */
void Log_Init() {
	char path[PATHLEN];
	struct mq_attr attr;
//	attr.mq_maxmsg = 4096;
//	attr.mq_msgsize = 4096;


	mqd = mq_open(MQD_NAME, O_RDWR | O_CREAT | O_NONBLOCK, S_IRUSR | S_IWUSR , NULL);
		if (mqd == -1)
			fprintf(stderr, "mq_open(): %s\n", strerror(errno));

	get_path(path, LOGROOT);
	logfile = fopen(path, "a");
	if (logfile == NULL) {
		fprintf(stderr, "Can not access logfile %s : Permission denied\n", path);
	}
}

void Log_Send(int levelno, int typeno, char *format, ...) {
	va_list args;

	va_start(args, format);
	memset(LogLine, 0, 4096);
	Log_Fill_LogLine(levelno, typeno, format, args);
	va_end(args);
	//fprintf(stderr, "LogLine: %s %ld", LogLine, strlen(LogLine));
	if (mq_send(mqd, LogLine, strlen(LogLine), levelno) == -1) {
		fprintf(stderr, "%s :mq_send()[%s]\n", strerror(errno), __func__);
	}
	memset(LogLine, 0, strlen(LogLine));
}

void Log_Fill_LogLine(int levelno, int typeno, char *format, va_list args) {
	char time_string[TIMELEN] = {0x0};

	sprintf(LogLine, "[%s] ", LogLevelText[levelno]);
	Log_Time(time_string);
	strcat(LogLine, time_string);
	strcat(LogLine, " ");
	Log_Print(format, args);
	strcat(LogLine, " (");
	strcat(LogLine, LogTypeText[typeno]);
	strcat(LogLine, ") \n\0");
}

void print_attr_info(struct mq_attr *attr) {
	printf("[mq_attr_info]:");
	printf("mq_msgsize: %ld\n", attr->mq_msgsize);
	printf("mq_flag: %ld\n", attr->mq_flags);
	printf("mq_maxmsg: %ld\n", attr->mq_maxmsg);
	printf("mq_curmsg: %ld\n", attr->mq_curmsgs);
}

void Log_Write() {
		struct mq_attr attr;
		unsigned int level;


	//	mq_getattr(mqd, &attr);
	//	print_attr_info(&attr);

		while(mq_receive(mqd, LogLine, MQ_MSGSIZE, &level) > 0) {
				fprintf(logfile, "%s", LogLine);
				memset(LogLine, 0, strlen(LogLine));
		}
	
//  	mq_close(mqd);
}
void Log_Print(char *format, va_list args) {
	int d;
	char c, *s;
	int has_percent = 0;
	char temp[64];
	
	while(*format)
	{
		switch(*format){
			case '%' :
				has_percent = 1;
				break;
			case's':{
				if (has_percent) {
					s =va_arg(args,char*);

					strcat(LogLine, s);
					has_percent = 0;
				} else {
					strcat(LogLine, "s");
				}
				break;
			}
			case'd':{
				if (has_percent) {
					d =va_arg(args,int);
					sprintf(temp,"%d",d);
					strcat(LogLine, temp);
					has_percent = 0;
				} else {
					strcat(LogLine, "d");
				}
				break;
			}
			case'c':{
				if (has_percent) {
					c =(char)va_arg(args,int);
					sprintf(temp,"%c",c);
					strcat(LogLine, temp);
					has_percent = 0;
				} else {
					strcat(LogLine, "c");
				}
				break;
			}
			default:{
				if(*format!='%') {
					sprintf(temp,"%c",*format);
					strcat(LogLine, temp);
				}
				break;
			}
		}
	format++;
	}
}
void Log_Time(char *time_string) {
	struct tm* ptm;
	struct timeval tv;
	if (gettimeofday(&tv, NULL) == -1) {
		fprintf(logfile, "%s:gettimeofday() error\n", __func__);
	}
  
  //gettimeofday (&tv, NULL);
  ptm = localtime (&tv.tv_sec);
  strftime (time_string,  TIMELEN, "%Y-%m-%d %H:%M:%S", ptm);
}
void get_date(char *date) {
	struct timeval tv;
	struct tm *tm;
	gettimeofday(&tv, NULL);
  tm = localtime (&tv.tv_sec);
  strftime (date,  TIMELEN, "%Y%m%d", tm);
}
void get_path(char *path, char *docroot) {
	char date[TIMELEN];
	get_date(date);
	sprintf(path, "%sqiqiao-%s.log", docroot, date);	
}


