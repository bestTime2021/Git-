#include "log.c"
#include <assert.h>

int main() {
	Log_Init();
	while(1) {
		sleep(3);
		struct mq_attr attr;
		unsigned int level;


		mq_getattr(mqd, &attr);
//		printf("hh\n");
		print_attr_info(&attr);
		Log_Write();
		sleep(3);
		fflush(logfile);
		fprintf(stderr, "%s\n", strerror(errno));
	
		printf("LOG END\n");
	}
}
