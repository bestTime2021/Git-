#include "log.c"

int main() {
	Log_Init();
	Log_Send(DEBUG, SERVER, "yes i succeed!");
	Log_Send(INFO, PROGRAM, "world!");

}
