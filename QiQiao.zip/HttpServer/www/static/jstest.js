function myFunction() {
    document.getElementById("demo").innerHTML = "jstest successfully";
 }